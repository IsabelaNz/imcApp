package br.fecapads.calculadoraimc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class telaPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_principal);

        // Botão da minha tela principal que leva até a calculadora de imc

        Button botaoIrParaMain = findViewById(R.id.btnCalcularIMC);
        botaoIrParaMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(telaPrincipal.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}